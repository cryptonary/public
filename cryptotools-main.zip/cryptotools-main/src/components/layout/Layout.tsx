
import { useState } from "react";
import { Outlet, Link, useLocation } from "react-router-dom";
import { ThemeToggle } from "@/components/theme/theme-toggle";
import { Button } from "@/components/ui/button";
import { Menu, Calculator, Wallet, CreditCard, BarChart2, LineChart, BookOpen } from "lucide-react";

const Layout = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();
  
  const navItems = [
    { path: "/profit-calculator", label: "Profit Calculator", icon: <Calculator size={18} /> },
    { path: "/dca-calculator", label: "DCA Calculator", icon: <LineChart size={18} /> },
    { path: "/crypto-converter", label: "Crypto Converter", icon: <CreditCard size={18} /> },
    { path: "/investment-tracker", label: "Investment Tracker", icon: <Wallet size={18} /> },
    { path: "/price-simulator", label: "Price Simulator", icon: <BarChart2 size={18} /> },
    { path: "/crypto-research", label: "Crypto Research", icon: <BookOpen size={18} /> },
  ];

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="sticky top-0 z-40 border-b bg-background/80 backdrop-blur-sm">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="md:hidden"
            >
              <Menu />
            </Button>
            <Link to="/" className="flex items-center gap-2">
              <div className="size-8 rounded-full crypto-gradient-bg flex items-center justify-center">
                <Wallet className="text-white" size={18} />
              </div>
              <span className="font-bold text-xl">CryptoTools</span>
            </Link>
          </div>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-6">
            {navItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center gap-1.5 text-sm font-medium transition-colors hover:text-primary ${
                  location.pathname === item.path ? "text-primary" : "text-muted-foreground"
                }`}
              >
                {item.icon}
                {item.label}
              </Link>
            ))}
          </nav>
          
          <div className="flex items-center gap-2">
            <ThemeToggle />
          </div>
        </div>
      </header>

      {/* Mobile Navigation */}
      <div
        className={`fixed inset-0 z-30 bg-background/80 backdrop-blur-sm md:hidden transition-all ${
          isMenuOpen ? "opacity-100" : "opacity-0 pointer-events-none"
        }`}
        onClick={() => setIsMenuOpen(false)}
      />
      <div
        className={`fixed top-16 left-0 z-30 w-64 h-[calc(100vh-4rem)] bg-background border-r p-4 transition-transform md:hidden ${
          isMenuOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <nav className="flex flex-col gap-2">
          {navItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              className={`flex items-center gap-2 px-3 py-2 rounded-md text-sm font-medium transition-colors hover:bg-accent ${
                location.pathname === item.path ? "bg-accent text-accent-foreground" : "text-muted-foreground"
              }`}
              onClick={() => setIsMenuOpen(false)}
            >
              {item.icon}
              {item.label}
            </Link>
          ))}
        </nav>
      </div>

      {/* Main Content */}
      <main className="flex-1">
        <Outlet />
      </main>

      {/* Footer */}
      <footer className="border-t py-6 md:py-0">
        <div className="container flex flex-col md:flex-row items-center justify-between gap-4 md:h-16">
          <p className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} CryptoTools. All rights reserved.
          </p>
          <div className="flex items-center gap-4">
            <Link to="/" className="text-sm text-muted-foreground hover:text-foreground">
              Privacy
            </Link>
            <Link to="/" className="text-sm text-muted-foreground hover:text-foreground">
              Terms
            </Link>
            <Link to="/" className="text-sm text-muted-foreground hover:text-foreground">
              Contact
            </Link>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Layout;
