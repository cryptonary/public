
import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { LineChart, CartesianGrid, XAxis, YAxis, Tooltip, Legend, Line, ResponsiveContainer } from "recharts";
import { LineChart as LineChartIcon, Wallet } from "lucide-react";
import { Helmet } from "react-helmet-async";

interface DCAData {
  month: number;
  investment: number;
  coinsBought: number;
  coinPrice: number;
  totalCoins: number;
  portfolioValue: number;
  averageCost: number;
}

const DcaCalculator = () => {
  const [investmentAmount, setInvestmentAmount] = useState<string>("100");
  const [frequency, setFrequency] = useState<string>("monthly");
  const [period, setPeriod] = useState<string>("12");
  const [initialPrice, setInitialPrice] = useState<string>("50000");
  const [priceVolatility, setPriceVolatility] = useState<string>("5"); // percentage price change per period
  const [dcaData, setDcaData] = useState<DCAData[]>([]);
  const [activeTab, setActiveTab] = useState<string>("chart");

  useEffect(() => {
    calculateDCA();
  }, [investmentAmount, frequency, period, initialPrice, priceVolatility]);

  const calculateDCA = () => {
    const investment = parseFloat(investmentAmount) || 0;
    const months = parseInt(period) || 0;
    const startPrice = parseFloat(initialPrice) || 0;
    const volatility = parseFloat(priceVolatility) || 0;
    
    if (investment <= 0 || months <= 0 || startPrice <= 0) {
      setDcaData([]);
      return;
    }
    
    const data: DCAData[] = [];
    let totalCoins = 0;
    let totalInvestment = 0;
    let currentPrice = startPrice;
    
    for (let month = 1; month <= months; month++) {
      // Simulate price change with volatility and a slight upward trend
      const randomFactor = (Math.random() - 0.45) * volatility / 100;
      currentPrice = currentPrice * (1 + randomFactor);
      
      const periodInvestment = investment;
      totalInvestment += periodInvestment;
      
      const coinsBought = periodInvestment / currentPrice;
      totalCoins += coinsBought;
      
      const portfolioValue = totalCoins * currentPrice;
      const averageCost = totalInvestment / totalCoins;
      
      data.push({
        month,
        investment: totalInvestment,
        coinsBought,
        coinPrice: currentPrice,
        totalCoins,
        portfolioValue,
        averageCost
      });
    }
    
    setDcaData(data);
  };

  const formatCurrency = (value: number): string => {
    return new Intl.NumberFormat('en-US', { 
      style: 'currency', 
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(value);
  };

  // Extract final results for display
  const finalData = dcaData.length > 0 ? dcaData[dcaData.length - 1] : {
    investment: 0,
    totalCoins: 0,
    portfolioValue: 0,
    averageCost: 0,
    coinPrice: 0
  };

  const profitLoss = finalData.portfolioValue - finalData.investment;
  const profitLossPercentage = finalData.investment > 0 
    ? ((finalData.portfolioValue / finalData.investment) - 1) * 100 
    : 0;

  const faqs = [
    {
      question: "What is Dollar-Cost Averaging (DCA)?",
      answer: "Dollar-Cost Averaging is an investment strategy where you invest a fixed amount of money at regular intervals, regardless of the asset's price. This approach can reduce the impact of volatility and potentially lower the average cost per unit of the investment over time."
    },
    {
      question: "Why is DCA considered effective for cryptocurrency investing?",
      answer: "Cryptocurrencies are known for their high volatility. DCA helps mitigate the risk of making a large investment at an unfavorable price point. By spreading investments over time, you can potentially achieve a more balanced entry price and reduce the psychological stress of trying to time the market."
    },
    {
      question: "How does this DCA calculator simulate price changes?",
      answer: "Our calculator uses a simplified model that incorporates random price movements based on the volatility percentage you set. It's important to note that this is a simulation and not a prediction of future prices. Real cryptocurrency price movements are influenced by many complex factors that cannot be fully modeled."
    },
    {
      question: "Can I use DCA for any cryptocurrency?",
      answer: "Yes, the DCA strategy can be applied to any cryptocurrency or traditional investment. This calculator allows you to simulate DCA for any crypto asset by entering its current price and adjusting the volatility to match your expectations for that particular cryptocurrency."
    },
    {
      question: "How do I determine the ideal frequency and amount for DCA?",
      answer: "The ideal frequency and amount depend on your financial situation, investment goals, and risk tolerance. Many investors align their DCA schedule with their income frequency (weekly, bi-weekly, or monthly). You can use this calculator to experiment with different scenarios to find what works best for your situation."
    }
  ];

  return (
    <div className="container py-10 md:py-20">
      <Helmet>
        <title>DCA Calculator - Dollar-Cost Averaging Strategy Simulator</title>
        <meta name="description" content="Visualize the power of dollar-cost averaging for your cryptocurrency investments with our interactive DCA calculator and simulator." />
        <meta name="keywords" content="dollar cost averaging, DCA calculator, crypto investment strategy, cryptocurrency DCA, bitcoin DCA" />
        <script type="application/ld+json">
          {JSON.stringify({
            "@context": "https://schema.org",
            "@type": "SoftwareApplication",
            "name": "DCA Calculator",
            "applicationCategory": "FinanceApplication",
            "operatingSystem": "Web",
            "offers": {
              "@type": "Offer",
              "price": "0",
              "priceCurrency": "USD"
            },
            "description": "Simulate dollar-cost averaging strategy for cryptocurrency investments."
          })}
        </script>
        <script type="application/ld+json">
          {JSON.stringify({
            "@context": "https://schema.org",
            "@type": "FAQPage",
            "mainEntity": faqs.map(faq => ({
              "@type": "Question",
              "name": faq.question,
              "acceptedAnswer": {
                "@type": "Answer",
                "text": faq.answer
              }
            }))
          })}
        </script>
      </Helmet>

      <div className="text-center mb-10">
        <h1 className="text-3xl md:text-4xl font-bold mb-4">DCA Calculator</h1>
        <p className="text-muted-foreground max-w-3xl mx-auto">
          Dollar-Cost Averaging (DCA) is a powerful investment strategy where you invest a fixed amount at regular intervals, 
          regardless of price fluctuations. This approach can help reduce the impact of volatility on your cryptocurrency investments 
          and potentially lower your average purchase price over time.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Input Section */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Wallet className="text-crypto-purple" />
              <CardTitle>DCA Parameters</CardTitle>
            </div>
            <CardDescription>Configure your investment strategy</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="investmentAmount">Investment Amount (USD)</Label>
              <Input
                id="investmentAmount"
                type="number"
                min="0"
                step="any"
                value={investmentAmount}
                onChange={(e) => setInvestmentAmount(e.target.value)}
                className="input-field"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="frequency">Investment Frequency</Label>
              <Select value={frequency} onValueChange={setFrequency}>
                <SelectTrigger id="frequency">
                  <SelectValue placeholder="Select frequency" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="weekly">Weekly</SelectItem>
                  <SelectItem value="monthly">Monthly</SelectItem>
                  <SelectItem value="quarterly">Quarterly</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="period">Investment Duration (Months)</Label>
              <Input
                id="period"
                type="number"
                min="1"
                max="60"
                value={period}
                onChange={(e) => setPeriod(e.target.value)}
                className="input-field"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="initialPrice">Initial Coin Price (USD)</Label>
              <Input
                id="initialPrice"
                type="number"
                min="0.000001"
                step="any"
                value={initialPrice}
                onChange={(e) => setInitialPrice(e.target.value)}
                className="input-field"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="volatility">Simulated Volatility (%)</Label>
              <Input
                id="volatility"
                type="number"
                min="1"
                max="100"
                value={priceVolatility}
                onChange={(e) => setPriceVolatility(e.target.value)}
                className="input-field"
              />
              <p className="text-xs text-muted-foreground">
                Higher values create more price fluctuations in the simulation.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Results and Charts Section */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <div className="flex items-center gap-2">
              <LineChartIcon className="text-crypto-purple" />
              <CardTitle>DCA Results</CardTitle>
            </div>
            <CardDescription>Visualization of your DCA strategy</CardDescription>
          </CardHeader>
          <CardContent>
            {/* Summary Stats */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
              <div className="p-4 bg-accent/50 rounded-lg">
                <p className="text-sm text-muted-foreground mb-1">Total Invested</p>
                <p className="text-xl font-bold">{formatCurrency(finalData.investment)}</p>
              </div>
              <div className="p-4 bg-accent/50 rounded-lg">
                <p className="text-sm text-muted-foreground mb-1">Final Value</p>
                <p className="text-xl font-bold">{formatCurrency(finalData.portfolioValue)}</p>
              </div>
              <div className="p-4 bg-accent/50 rounded-lg">
                <p className="text-sm text-muted-foreground mb-1">Profit/Loss</p>
                <p className={`text-xl font-bold ${profitLoss >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                  {formatCurrency(profitLoss)} ({profitLossPercentage.toFixed(2)}%)
                </p>
              </div>
              <div className="p-4 bg-accent/50 rounded-lg">
                <p className="text-sm text-muted-foreground mb-1">Total Coins</p>
                <p className="text-xl font-bold">{finalData.totalCoins.toFixed(8)}</p>
              </div>
              <div className="p-4 bg-accent/50 rounded-lg">
                <p className="text-sm text-muted-foreground mb-1">Average Cost</p>
                <p className="text-xl font-bold">{formatCurrency(finalData.averageCost)}</p>
              </div>
              <div className="p-4 bg-accent/50 rounded-lg">
                <p className="text-sm text-muted-foreground mb-1">Current Price</p>
                <p className="text-xl font-bold">{formatCurrency(finalData.coinPrice)}</p>
              </div>
            </div>

            {/* Visualization Tabs */}
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-2 mb-6">
                <TabsTrigger value="chart">Chart View</TabsTrigger>
                <TabsTrigger value="data">Data Table</TabsTrigger>
              </TabsList>
              
              <TabsContent value="chart" className="space-y-4">
                {dcaData.length > 0 ? (
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={dcaData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="month" label={{ value: 'Month', position: 'insideBottom', offset: -5 }} />
                        <YAxis />
                        <Tooltip formatter={(value: number) => formatCurrency(value)} />
                        <Legend />
                        <Line 
                          type="monotone" 
                          dataKey="investment" 
                          name="Total Investment"
                          stroke="#7E69AB" 
                          strokeWidth={2} 
                          dot={false} 
                        />
                        <Line 
                          type="monotone" 
                          dataKey="portfolioValue" 
                          name="Portfolio Value"
                          stroke="#8B5CF6" 
                          strokeWidth={2} 
                          dot={false} 
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                ) : (
                  <div className="text-center py-10 text-muted-foreground">
                    Enter valid parameters to see the chart
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="data">
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr className="bg-muted/50">
                        <th className="p-2 text-left">Month</th>
                        <th className="p-2 text-left">Investment</th>
                        <th className="p-2 text-left">Coin Price</th>
                        <th className="p-2 text-left">Total Coins</th>
                        <th className="p-2 text-left">Portfolio Value</th>
                      </tr>
                    </thead>
                    <tbody>
                      {dcaData.map((data, index) => (
                        <tr key={index} className="border-t border-border">
                          <td className="p-2">{data.month}</td>
                          <td className="p-2">{formatCurrency(data.investment)}</td>
                          <td className="p-2">{formatCurrency(data.coinPrice)}</td>
                          <td className="p-2">{data.totalCoins.toFixed(8)}</td>
                          <td className="p-2">{formatCurrency(data.portfolioValue)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>

      {/* Understanding DCA Section */}
      <div className="mt-16">
        <h2 className="text-2xl font-bold mb-6 text-center">Understanding Dollar-Cost Averaging</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <h3 className="text-xl font-semibold mb-3">The Benefits of DCA</h3>
            <ul className="list-disc pl-5 space-y-2 text-muted-foreground">
              <li>
                <span className="font-semibold">Reduced risk of poor timing:</span> By spreading investments over time, you avoid the risk of investing all your money at market peaks.
              </li>
              <li>
                <span className="font-semibold">Emotional discipline:</span> DCA removes the stress of trying to time the market and encourages consistent investing habits.
              </li>
              <li>
                <span className="font-semibold">Potential lower average cost:</span> By buying more units when prices are lower and fewer when prices are higher, your average cost per unit can potentially be reduced.
              </li>
              <li>
                <span className="font-semibold">Compounding opportunities:</span> Regular investing allows you to benefit from compound growth over longer periods.
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-xl font-semibold mb-3">DCA Best Practices</h3>
            <ul className="list-disc pl-5 space-y-2 text-muted-foreground">
              <li>
                <span className="font-semibold">Consistency is key:</span> Stick to your investment schedule regardless of market conditions or news.
              </li>
              <li>
                <span className="font-semibold">Choose a comfortable amount:</span> Invest an amount you can consistently afford without straining your finances.
              </li>
              <li>
                <span className="font-semibold">Consider automation:</span> Set up automatic transfers to ensure you don't miss investment intervals.
              </li>
              <li>
                <span className="font-semibold">Long-term perspective:</span> DCA works best over extended timeframes, ideally years rather than months.
              </li>
              <li>
                <span className="font-semibold">Reassess periodically:</span> Review your DCA strategy annually, but avoid making frequent changes based on short-term market movements.
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* FAQs */}
      <div className="mt-16">
        <h2 className="text-2xl font-bold mb-6 text-center">Frequently Asked Questions</h2>
        
        <div className="space-y-6">
          {faqs.map((faq, index) => (
            <div key={index} className="border border-border/50 rounded-lg p-6">
              <h3 className="text-xl font-semibold mb-2">{faq.question}</h3>
              <p className="text-muted-foreground">{faq.answer}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default DcaCalculator;
