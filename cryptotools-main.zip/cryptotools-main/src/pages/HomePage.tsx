
import { useState } from "react";
import { Link } from "react-router-dom";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { Calculator, LineChart, CreditCard, Wallet, BarChart2 } from "lucide-react";
import { Helmet } from "react-helmet-async";

const HomePage = () => {
  const [email, setEmail] = useState("");

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email && email.includes('@') && email.includes('.')) {
      toast.success("Thanks for subscribing to our newsletter!");
      setEmail("");
    } else {
      toast.error("Please enter a valid email address");
    }
  };

  const tools = [
    {
      icon: <Calculator className="h-10 w-10 text-crypto-purple" />,
      title: "Profit Calculator",
      description: "Calculate your potential profits or losses from cryptocurrency investments.",
      link: "/profit-calculator",
    },
    {
      icon: <LineChart className="h-10 w-10 text-crypto-purple" />,
      title: "DCA Calculator",
      description: "Simulate dollar-cost averaging investment strategy over time.",
      link: "/dca-calculator",
    },
    {
      icon: <CreditCard className="h-10 w-10 text-crypto-purple" />,
      title: "Crypto Converter",
      description: "Convert cryptocurrencies to various fiat currencies and vice versa.",
      link: "/crypto-converter",
    },
    {
      icon: <Wallet className="h-10 w-10 text-crypto-purple" />,
      title: "Investment Tracker",
      description: "Track and analyze your crypto portfolio performance over time.",
      link: "/investment-tracker",
    },
    {
      icon: <BarChart2 className="h-10 w-10 text-crypto-purple" />,
      title: "Price Simulator",
      description: "Visualize and simulate potential price movements of cryptocurrencies.",
      link: "/price-simulator",
    },
  ];

  const testimonials = [
    {
      quote: "These crypto calculators have been invaluable for my investment strategy.",
      author: "Alex M.",
      role: "Crypto Investor",
    },
    {
      quote: "The DCA calculator helped me understand the power of consistent investing.",
      author: "Sarah L.",
      role: "Finance Blogger",
    },
    {
      quote: "As a beginner, these tools made crypto much more approachable.",
      author: "Michael T.",
      role: "Crypto Enthusiast",
    },
  ];

  const faqs = [
    {
      question: "What are cryptocurrency calculators and why are they useful?",
      answer: "Cryptocurrency calculators are specialized tools designed to help investors make informed decisions by providing mathematical projections of potential profits, losses, and investment scenarios. They're useful because they eliminate complex manual calculations, allow for quick scenario testing, and help visualize potential outcomes of different investment strategies."
    },
    {
      question: "Are these calculators suitable for beginners?",
      answer: "Yes, our calculators are designed with both beginners and experienced traders in mind. Each tool has a user-friendly interface with clear instructions and explanations. If you're new to cryptocurrency investing, these tools can help you understand concepts like dollar-cost averaging, profit potential, and price conversion."
    },
    {
      question: "How accurate are the price simulations and projections?",
      answer: "The simulations and projections are based on mathematical models and historical data patterns, but it's important to understand they're not predictions of future performance. Cryptocurrency markets are highly volatile and influenced by many factors. Our tools provide reasonable estimates based on the parameters you enter, but actual results may vary significantly."
    },
    {
      question: "Do I need to create an account to use these tools?",
      answer: "No, all our cryptocurrency calculators and tools are freely available without requiring registration or account creation. You can start using them immediately to plan your investment strategies."
    },
    {
      question: "Can I save or export my calculation results?",
      answer: "Currently, the tools don't offer direct export functionality, but you can take screenshots or note down the results for your reference. We're considering adding export features in future updates."
    }
  ];

  return (
    <div className="flex flex-col min-h-screen">
      <Helmet>
        <title>CryptoCalc Pro - Powerful Cryptocurrency Investment Tools</title>
        <meta name="description" content="Make better crypto investment decisions with our suite of calculators and tools, designed for both beginners and experienced traders." />
        <meta name="keywords" content="cryptocurrency calculators, crypto tools, profit calculator, DCA, dollar cost averaging, investment tracker" />
        <script type="application/ld+json">
          {JSON.stringify({
            "@context": "https://schema.org",
            "@type": "Organization",
            "name": "CryptoCalc Pro",
            "url": "https://cryptocalcpro.com",
            "logo": "https://cryptocalcpro.com/logo.png",
            "description": "Powerful cryptocurrency calculators and investment tools",
            "sameAs": [
              "https://twitter.com/cryptocalcpro",
              "https://facebook.com/cryptocalcpro",
              "https://linkedin.com/company/cryptocalcpro"
            ],
            "contactPoint": {
              "@type": "ContactPoint",
              "email": "support@cryptocalcpro.com",
              "contactType": "customer service"
            }
          })}
        </script>
        <script type="application/ld+json">
          {JSON.stringify({
            "@context": "https://schema.org",
            "@type": "WebSite",
            "url": "https://cryptocalcpro.com",
            "name": "CryptoCalc Pro",
            "description": "Powerful cryptocurrency calculators and investment tools",
            "potentialAction": {
              "@type": "SearchAction",
              "target": "https://cryptocalcpro.com/search?q={search_term_string}",
              "query-input": "required name=search_term_string"
            }
          })}
        </script>
      </Helmet>
      
      {/* Hero Section */}
      <section className="relative py-20 md:py-32 overflow-hidden">
        {/* Background Elements */}
        <div className="absolute top-20 right-10 size-64 rounded-full bg-crypto-purple/10 blur-3xl animate-pulse-slow" />
        <div className="absolute bottom-10 -left-20 size-64 rounded-full bg-crypto-blue/10 blur-3xl animate-pulse-slow" />
        
        <div className="container relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight mb-6 animate-slide-up">
              Powerful Crypto Tools <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-crypto-purple to-crypto-blue">
                At Your Fingertips
              </span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8 animate-slide-up" style={{animationDelay: "0.1s"}}>
              Make better crypto investment decisions with our suite of calculators and tools, 
              designed for both beginners and experienced traders.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center animate-slide-up" style={{animationDelay: "0.2s"}}>
              <Button asChild size="lg" className="crypto-gradient-bg">
                <Link to="/profit-calculator">Get Started</Link>
              </Button>
              <Button asChild variant="outline" size="lg">
                <Link to="#tools">Explore Tools</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-16 bg-card/30">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-6">Why Use Our Crypto Tools?</h2>
            <p className="text-lg text-muted-foreground mb-10">
              In the volatile world of cryptocurrency, having the right tools to analyze investments and trends 
              can make all the difference. Our calculators help you make data-driven decisions, reduce emotional trading, 
              and understand the potential outcomes of various investment strategies.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-8">
            <div className="text-center p-6">
              <div className="bg-crypto-purple/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Calculator className="h-8 w-8 text-crypto-purple" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Informed Decisions</h3>
              <p className="text-muted-foreground">
                Make better investment choices with data-backed calculations and visual projections of potential outcomes.
              </p>
            </div>
            
            <div className="text-center p-6">
              <div className="bg-crypto-purple/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <LineChart className="h-8 w-8 text-crypto-purple" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Risk Management</h3>
              <p className="text-muted-foreground">
                Understand potential risks and rewards before committing your capital to cryptocurrency investments.
              </p>
            </div>
            
            <div className="text-center p-6">
              <div className="bg-crypto-purple/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Wallet className="h-8 w-8 text-crypto-purple" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Strategy Optimization</h3>
              <p className="text-muted-foreground">
                Test and refine your investment strategies using our advanced simulation and calculation tools.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Tools Section */}
      <section id="tools" className="py-20 bg-accent/50">
        <div className="container">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="text-3xl font-bold mb-4">Our Crypto Tools</h2>
            <p className="text-muted-foreground">
              Discover our range of powerful tools designed to help you make informed decisions about your crypto investments.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {tools.map((tool, index) => (
              <Card key={index} className="card-hover overflow-hidden border border-border/50">
                <CardHeader>
                  <div className="mb-2">{tool.icon}</div>
                  <CardTitle>{tool.title}</CardTitle>
                  <CardDescription>{tool.description}</CardDescription>
                </CardHeader>
                <CardFooter>
                  <Button asChild variant="secondary" className="w-full">
                    <Link to={tool.link}>Use Tool</Link>
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20">
        <div className="container">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="text-3xl font-bold mb-4">What Users Say</h2>
            <p className="text-muted-foreground">
              Don't just take our word for it — see what our community thinks about our tools.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="bg-card/50 border border-border/50">
                <CardContent className="pt-6">
                  <div className="mb-4 text-4xl text-crypto-purple">"</div>
                  <p className="mb-4 italic">{testimonial.quote}</p>
                  <div>
                    <p className="font-semibold">{testimonial.author}</p>
                    <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* FAQs Section */}
      <section className="py-20 bg-card/30">
        <div className="container">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="text-3xl font-bold mb-4">Frequently Asked Questions</h2>
            <p className="text-muted-foreground mb-8">
              Find answers to common questions about our cryptocurrency tools and calculators.
            </p>
          </div>

          <div className="max-w-3xl mx-auto">
            {faqs.map((faq, index) => (
              <div key={index} className="mb-6 border-b border-border/50 pb-6 last:border-0">
                <h3 className="text-xl font-semibold mb-2">{faq.question}</h3>
                <p className="text-muted-foreground">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Newsletter */}
      <section className="py-20 crypto-gradient-bg text-white">
        <div className="container">
          <div className="max-w-2xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-4">Stay Updated</h2>
            <p className="mb-6 text-white/80">
              Subscribe to our newsletter for the latest crypto news, tool updates, and investment insights.
            </p>
            <form onSubmit={handleNewsletterSubmit} className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
              <Input
                type="email"
                placeholder="Enter your email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="bg-white/20 border-white/30 text-white placeholder:text-white/60 focus:border-white"
              />
              <Button type="submit" variant="secondary">
                Subscribe
              </Button>
            </form>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;
