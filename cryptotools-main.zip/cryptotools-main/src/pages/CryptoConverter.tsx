
import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { ArrowRight, CreditCard, ArrowDown } from "lucide-react";
import { Helmet } from "react-helmet-async";

// Predefined crypto and fiat options
const cryptocurrencies = ["BTC", "ETH", "ADA", "SOL", "XRP", "DOT", "DOGE", "LINK"];
const fiatCurrencies = ["USD", "EUR", "GBP", "JPY", "CAD", "AUD", "CNY", "INR"];

const CryptoConverter = () => {
  const [amount, setAmount] = useState<string>("1");
  const [fromCurrency, setFromCurrency] = useState<string>("BTC");
  const [toCurrency, setToCurrency] = useState<string>("USD");
  const [exchangeRate, setExchangeRate] = useState<string>("50000");
  const [convertedAmount, setConvertedAmount] = useState<number>(0);
  const [isCryptoToFiat, setIsCryptoToFiat] = useState<boolean>(true);

  useEffect(() => {
    convertCurrency();
  }, [amount, fromCurrency, toCurrency, exchangeRate, isCryptoToFiat]);

  const convertCurrency = () => {
    const inputAmount = parseFloat(amount) || 0;
    const rate = parseFloat(exchangeRate) || 0;
    
    if (inputAmount <= 0 || rate <= 0) {
      setConvertedAmount(0);
      return;
    }
    
    if (isCryptoToFiat) {
      // Crypto to Fiat
      setConvertedAmount(inputAmount * rate);
    } else {
      // Fiat to Crypto
      setConvertedAmount(inputAmount / rate);
    }
  };

  const swapCurrencies = () => {
    setIsCryptoToFiat(!isCryptoToFiat);
    // Reset selections to appropriate defaults when swapping directions
    if (isCryptoToFiat) {
      setFromCurrency("USD");
      setToCurrency("BTC");
    } else {
      setFromCurrency("BTC");
      setToCurrency("USD");
    }
    setAmount("1");
  };

  const formatCurrency = (value: number, currencyCode: string): string => {
    if (cryptocurrencies.includes(currencyCode)) {
      // For cryptocurrencies, show up to 8 decimal places
      return `${value.toFixed(8)} ${currencyCode}`;
    } else {
      // For fiat currencies, use currency formatting
      return new Intl.NumberFormat('en-US', { 
        style: 'currency', 
        currency: currencyCode,
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
      }).format(value);
    }
  };

  const getFromOptions = () => {
    return isCryptoToFiat ? cryptocurrencies : fiatCurrencies;
  };

  const getToOptions = () => {
    return isCryptoToFiat ? fiatCurrencies : cryptocurrencies;
  };

  const faqs = [
    {
      question: "How accurate are the conversion rates?",
      answer: "The conversion rates used in this tool are manually entered by you. For the most accurate conversions, we recommend checking current market rates on exchanges or cryptocurrency price tracking websites and entering those values."
    },
    {
      question: "Why do I need to enter the exchange rate manually?",
      answer: "Unlike typical currency converters that use real-time data, our converter allows you to input specific exchange rates. This gives you more flexibility for hypothetical scenarios, historical analysis, or using rates from your preferred exchange."
    },
    {
      question: "Can I convert between two cryptocurrencies?",
      answer: "This version of the converter is designed specifically for crypto-to-fiat or fiat-to-crypto conversions. To convert between two cryptocurrencies, you would need to perform two separate conversions using a common fiat currency as an intermediate step."
    },
    {
      question: "What is the difference between market price and exchange rate?",
      answer: "The market price is the current trading value of a cryptocurrency on exchanges. The exchange rate in our converter can be the market price, but you might choose to use different values based on your specific exchange's rates, which may include fees or spreads."
    },
    {
      question: "Why might conversion rates vary across different platforms?",
      answer: "Cryptocurrency prices can vary across exchanges due to differences in liquidity, trading volumes, regional factors, and fees. This is known as price fragmentation in the crypto market."
    }
  ];

  return (
    <div className="container py-10 md:py-20 max-w-3xl">
      <Helmet>
        <title>Crypto Converter - Convert Between Cryptocurrencies and Fiat</title>
        <meta name="description" content="Easily convert between cryptocurrencies and fiat currencies with our flexible converter tool. Enter custom exchange rates for precise calculations." />
        <meta name="keywords" content="crypto converter, cryptocurrency exchange calculator, bitcoin calculator, crypto to fiat, fiat to crypto" />
        <script type="application/ld+json">
          {JSON.stringify({
            "@context": "https://schema.org",
            "@type": "SoftwareApplication",
            "name": "Crypto Converter",
            "applicationCategory": "FinanceApplication",
            "operatingSystem": "Web",
            "offers": {
              "@type": "Offer",
              "price": "0",
              "priceCurrency": "USD"
            },
            "description": "Convert between cryptocurrencies and fiat currencies with customizable exchange rates."
          })}
        </script>
        <script type="application/ld+json">
          {JSON.stringify({
            "@context": "https://schema.org",
            "@type": "FAQPage",
            "mainEntity": faqs.map(faq => ({
              "@type": "Question",
              "name": faq.question,
              "acceptedAnswer": {
                "@type": "Answer",
                "text": faq.answer
              }
            }))
          })}
        </script>
      </Helmet>

      <div className="text-center mb-10">
        <h1 className="text-3xl md:text-4xl font-bold mb-4">Crypto Converter</h1>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          Easily convert between cryptocurrencies and fiat currencies with our flexible calculator. 
          Enter your own exchange rates for more precise calculations based on your preferred exchange or scenario.
        </p>
      </div>

      <Card className="overflow-hidden">
        <CardHeader className="bg-accent/50">
          <div className="flex items-center gap-2">
            <CreditCard className="text-crypto-purple" />
            <CardTitle>Currency Converter</CardTitle>
          </div>
          <CardDescription>Enter exchange rates manually for accurate conversions</CardDescription>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="space-y-6">
            {/* Direction toggle */}
            <div className="flex justify-center mb-6">
              <div className="bg-accent/50 p-1 rounded-lg flex items-center">
                <span className={`px-4 py-2 rounded-md transition-all ${isCryptoToFiat ? 'bg-background shadow-sm' : ''}`}>
                  Crypto → Fiat
                </span>
                <Button variant="ghost" size="icon" onClick={swapCurrencies} className="mx-2">
                  <ArrowRight className="rotate-90" size={16} />
                </Button>
                <span className={`px-4 py-2 rounded-md transition-all ${!isCryptoToFiat ? 'bg-background shadow-sm' : ''}`}>
                  Fiat → Crypto
                </span>
              </div>
            </div>
            
            {/* From Currency */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="fromAmount">Amount</Label>
                <Input
                  id="fromAmount"
                  type="number"
                  min="0"
                  step="any"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="input-field"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="fromCurrency">From Currency</Label>
                <Select value={fromCurrency} onValueChange={setFromCurrency}>
                  <SelectTrigger id="fromCurrency">
                    <SelectValue placeholder="Select currency" />
                  </SelectTrigger>
                  <SelectContent>
                    {getFromOptions().map(currency => (
                      <SelectItem key={currency} value={currency}>{currency}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            {/* Exchange Rate */}
            <div className="space-y-2">
              <Label htmlFor="exchangeRate">
                Exchange Rate ({isCryptoToFiat ? `1 ${fromCurrency} = ? ${toCurrency}` : `1 ${toCurrency} = ? ${fromCurrency}`})
              </Label>
              <Input
                id="exchangeRate"
                type="number"
                min="0.000001"
                step="any"
                value={exchangeRate}
                onChange={(e) => setExchangeRate(e.target.value)}
                className="input-field"
              />
            </div>
            
            <div className="flex justify-center py-2">
              <ArrowDown className="text-muted-foreground" />
            </div>
            
            {/* To Currency */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="toAmount">Converted Amount</Label>
                <div className="bg-accent/30 p-4 rounded-md border border-border/50 text-lg font-medium">
                  {formatCurrency(convertedAmount, toCurrency)}
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="toCurrency">To Currency</Label>
                <Select value={toCurrency} onValueChange={setToCurrency}>
                  <SelectTrigger id="toCurrency">
                    <SelectValue placeholder="Select currency" />
                  </SelectTrigger>
                  <SelectContent>
                    {getToOptions().map(currency => (
                      <SelectItem key={currency} value={currency}>{currency}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            {/* Conversion Formula */}
            <div className="mt-6 p-4 bg-accent/30 rounded-md border border-border/50">
              <p className="text-sm text-center">
                <span className="font-medium">{amount} {fromCurrency}</span>
                {isCryptoToFiat ? ' × ' : ' ÷ '}
                <span className="font-medium">{exchangeRate}</span>
                {' = '}
                <span className="font-medium">{formatCurrency(convertedAmount, toCurrency)}</span>
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Understanding Currency Conversion */}
      <div className="mt-16">
        <h2 className="text-2xl font-bold mb-6 text-center">Understanding Cryptocurrency Conversion</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <h3 className="text-xl font-semibold mb-3">How Crypto Conversion Works</h3>
            <p className="text-muted-foreground mb-4">
              Converting between cryptocurrencies and fiat currencies involves understanding exchange rates, which represent 
              the value of one currency in terms of another. These rates constantly fluctuate due to market forces.
            </p>
            <p className="text-muted-foreground">
              For crypto-to-fiat conversions, you multiply the crypto amount by the exchange rate. For fiat-to-crypto 
              conversions, you divide the fiat amount by the exchange rate.
            </p>
          </div>
          
          <div>
            <h3 className="text-xl font-semibold mb-3">Finding Accurate Exchange Rates</h3>
            <p className="text-muted-foreground mb-4">
              For the most accurate conversions, obtain current exchange rates from:
            </p>
            <ul className="list-disc pl-5 space-y-1 text-muted-foreground">
              <li>Cryptocurrency exchanges (Coinbase, Binance, Kraken)</li>
              <li>Price tracking websites (CoinMarketCap, CoinGecko)</li>
              <li>Financial news platforms with crypto sections</li>
            </ul>
            <p className="text-muted-foreground mt-4">
              Remember that rates can vary between different sources due to market liquidity, geographic regions, and platform fees.
            </p>
          </div>
        </div>
      </div>

      {/* FAQs */}
      <div className="mt-16">
        <h2 className="text-2xl font-bold mb-6 text-center">Frequently Asked Questions</h2>
        
        <div className="space-y-6">
          {faqs.map((faq, index) => (
            <div key={index} className="border border-border/50 rounded-lg p-6">
              <h3 className="text-xl font-semibold mb-2">{faq.question}</h3>
              <p className="text-muted-foreground">{faq.answer}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default CryptoConverter;
