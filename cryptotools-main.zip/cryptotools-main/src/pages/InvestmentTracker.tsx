
import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { 
  Table, TableBody, TableCaption, TableCell, TableHead, TableHeader, TableRow 
} from "@/components/ui/table";
import { Wallet, Plus, Trash, Edit, PieChart } from "lucide-react";
import { toast } from "sonner";
import { PieChart as ReChartPie, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from "recharts";

interface Investment {
  id: string;
  name: string;
  symbol: string;
  buyPrice: number;
  currentPrice: number;
  quantity: number;
}

const COLORS = ["#8B5CF6", "#9b87f5", "#7E69AB", "#D6BCFA", "#0EA5E9", "#F97316"];

const InvestmentTracker = () => {
  const [investments, setInvestments] = useState<Investment[]>([]);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [newInvestment, setNewInvestment] = useState<Investment>({
    id: "",
    name: "",
    symbol: "",
    buyPrice: 0,
    currentPrice: 0,
    quantity: 0
  });
  const [editInvestmentId, setEditInvestmentId] = useState<string | null>(null);

  // Load investments from local storage on component mount
  useEffect(() => {
    const savedInvestments = localStorage.getItem('crypto-investments');
    if (savedInvestments) {
      try {
        setInvestments(JSON.parse(savedInvestments));
      } catch (error) {
        console.error('Failed to parse saved investments:', error);
        toast.error("Failed to load your saved investments");
      }
    }
  }, []);

  // Save investments to local storage whenever they change
  useEffect(() => {
    localStorage.setItem('crypto-investments', JSON.stringify(investments));
  }, [investments]);

  const resetNewInvestment = () => {
    setNewInvestment({
      id: "",
      name: "",
      symbol: "",
      buyPrice: 0,
      currentPrice: 0,
      quantity: 0
    });
  };

  const handleAddInvestment = () => {
    if (!newInvestment.name || !newInvestment.symbol || newInvestment.buyPrice <= 0 || newInvestment.currentPrice <= 0 || newInvestment.quantity <= 0) {
      toast.error("Please fill in all fields with valid values");
      return;
    }

    const investmentToAdd = {
      ...newInvestment,
      id: Date.now().toString()
    };

    setInvestments([...investments, investmentToAdd]);
    resetNewInvestment();
    setIsAddDialogOpen(false);
    toast.success("Investment added successfully");
  };

  const handleEditInvestment = () => {
    if (!newInvestment.name || !newInvestment.symbol || newInvestment.buyPrice <= 0 || newInvestment.currentPrice <= 0 || newInvestment.quantity <= 0) {
      toast.error("Please fill in all fields with valid values");
      return;
    }

    const updatedInvestments = investments.map(investment => 
      investment.id === editInvestmentId ? newInvestment : investment
    );

    setInvestments(updatedInvestments);
    resetNewInvestment();
    setIsEditDialogOpen(false);
    setEditInvestmentId(null);
    toast.success("Investment updated successfully");
  };

  const handleDeleteInvestment = (id: string) => {
    const updatedInvestments = investments.filter(investment => investment.id !== id);
    setInvestments(updatedInvestments);
    toast.success("Investment deleted successfully");
  };

  const handleOpenEditDialog = (investment: Investment) => {
    setNewInvestment(investment);
    setEditInvestmentId(investment.id);
    setIsEditDialogOpen(true);
  };

  const formatCurrency = (value: number): string => {
    return new Intl.NumberFormat('en-US', { 
      style: 'currency', 
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(value);
  };

  const calculateTotalInvestment = (): number => {
    return investments.reduce((total, investment) => {
      return total + (investment.buyPrice * investment.quantity);
    }, 0);
  };

  const calculateCurrentValue = (): number => {
    return investments.reduce((total, investment) => {
      return total + (investment.currentPrice * investment.quantity);
    }, 0);
  };

  const calculateProfitLoss = (): number => {
    return calculateCurrentValue() - calculateTotalInvestment();
  };

  const calculateProfitLossPercentage = (): number => {
    const totalInvestment = calculateTotalInvestment();
    if (totalInvestment === 0) return 0;
    return ((calculateCurrentValue() / totalInvestment) - 1) * 100;
  };

  const calculateIndividualProfitLoss = (investment: Investment): number => {
    return (investment.currentPrice - investment.buyPrice) * investment.quantity;
  };

  const calculateIndividualProfitLossPercentage = (investment: Investment): number => {
    if (investment.buyPrice === 0) return 0;
    return ((investment.currentPrice / investment.buyPrice) - 1) * 100;
  };

  // Prepare data for the pie chart
  const pieChartData = investments.map(investment => ({
    name: investment.symbol,
    value: investment.currentPrice * investment.quantity
  }));

  return (
    <div className="container py-10 md:py-20">
      <div className="text-center mb-10">
        <h1 className="text-3xl md:text-4xl font-bold mb-4">Crypto Investment Tracker</h1>
        <p className="text-muted-foreground">
          Track your cryptocurrency investments and analyze your portfolio performance.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Portfolio Summary */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Wallet className="text-crypto-purple" />
              <CardTitle>Portfolio Summary</CardTitle>
            </div>
            <CardDescription>Overview of your investments</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="p-4 bg-accent/50 rounded-lg">
              <p className="text-sm text-muted-foreground mb-1">Total Investment</p>
              <p className="text-2xl font-bold">{formatCurrency(calculateTotalInvestment())}</p>
            </div>
            
            <div className="p-4 bg-accent/50 rounded-lg">
              <p className="text-sm text-muted-foreground mb-1">Current Value</p>
              <p className="text-2xl font-bold">{formatCurrency(calculateCurrentValue())}</p>
            </div>
            
            <div className="p-4 bg-accent/50 rounded-lg">
              <p className="text-sm text-muted-foreground mb-1">Profit/Loss</p>
              <p className={`text-2xl font-bold ${calculateProfitLoss() >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                {formatCurrency(calculateProfitLoss())} ({calculateProfitLossPercentage().toFixed(2)}%)
              </p>
            </div>

            {/* Portfolio Pie Chart */}
            {investments.length > 0 && (
              <div className="mt-6">
                <h3 className="text-sm font-medium mb-2 flex items-center gap-1">
                  <PieChart className="h-4 w-4 text-crypto-purple" />
                  Portfolio Allocation
                </h3>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <ReChartPie data={pieChartData}>
                      <Pie
                        data={pieChartData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {pieChartData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip 
                        formatter={(value: number) => formatCurrency(value)}
                      />
                      <Legend />
                    </ReChartPie>
                  </ResponsiveContainer>
                </div>
              </div>
            )}

            <Button 
              onClick={() => {
                resetNewInvestment();
                setIsAddDialogOpen(true);
              }}
              className="w-full crypto-gradient-bg"
            >
              <Plus className="mr-2 h-4 w-4" /> Add New Investment
            </Button>
          </CardContent>
        </Card>

        {/* Investments Table */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <div className="flex items-center gap-2">
              <PieChart className="text-crypto-purple" />
              <CardTitle>Your Investments</CardTitle>
            </div>
            <CardDescription>Manage your crypto investments</CardDescription>
          </CardHeader>
          <CardContent>
            {investments.length > 0 ? (
              <div className="overflow-x-auto">
                <Table>
                  <TableCaption>Your crypto portfolio tracking data is saved in your browser.</TableCaption>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Symbol</TableHead>
                      <TableHead className="text-right">Buy Price</TableHead>
                      <TableHead className="text-right">Current Price</TableHead>
                      <TableHead className="text-right">Quantity</TableHead>
                      <TableHead className="text-right">Value</TableHead>
                      <TableHead className="text-right">P/L</TableHead>
                      <TableHead className="text-center">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {investments.map((investment) => {
                      const profitLoss = calculateIndividualProfitLoss(investment);
                      const profitLossPercentage = calculateIndividualProfitLossPercentage(investment);
                      const currentValue = investment.currentPrice * investment.quantity;

                      return (
                        <TableRow key={investment.id}>
                          <TableCell className="font-medium">{investment.name}</TableCell>
                          <TableCell>{investment.symbol}</TableCell>
                          <TableCell className="text-right">{formatCurrency(investment.buyPrice)}</TableCell>
                          <TableCell className="text-right">{formatCurrency(investment.currentPrice)}</TableCell>
                          <TableCell className="text-right">{investment.quantity}</TableCell>
                          <TableCell className="text-right">{formatCurrency(currentValue)}</TableCell>
                          <TableCell 
                            className={`text-right ${profitLoss >= 0 ? 'text-green-500' : 'text-red-500'}`}
                          >
                            {formatCurrency(profitLoss)} <br />
                            <span className="text-xs">({profitLossPercentage.toFixed(2)}%)</span>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex items-center justify-end gap-2">
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                onClick={() => handleOpenEditDialog(investment)}
                              >
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                onClick={() => handleDeleteInvestment(investment.id)}
                              >
                                <Trash className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            ) : (
              <div className="text-center py-8">
                <Wallet className="h-16 w-16 text-muted-foreground/40 mx-auto mb-4" />
                <p className="text-muted-foreground mb-4">Your portfolio is empty. Add your first investment to get started.</p>
                <Button 
                  onClick={() => {
                    resetNewInvestment();
                    setIsAddDialogOpen(true);
                  }}
                >
                  <Plus className="mr-2 h-4 w-4" /> Add Investment
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Add Investment Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add New Investment</DialogTitle>
            <DialogDescription>
              Enter the details of your cryptocurrency investment.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Coin Name</Label>
                <Input
                  id="name"
                  placeholder="Bitcoin"
                  value={newInvestment.name}
                  onChange={(e) => setNewInvestment({...newInvestment, name: e.target.value})}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="symbol">Symbol</Label>
                <Input
                  id="symbol"
                  placeholder="BTC"
                  value={newInvestment.symbol}
                  onChange={(e) => setNewInvestment({...newInvestment, symbol: e.target.value.toUpperCase()})}
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="buyPrice">Buy Price (USD)</Label>
              <Input
                id="buyPrice"
                type="number"
                min="0.000001"
                step="any"
                placeholder="50000"
                value={newInvestment.buyPrice || ''}
                onChange={(e) => setNewInvestment({...newInvestment, buyPrice: parseFloat(e.target.value) || 0})}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="currentPrice">Current Price (USD)</Label>
              <Input
                id="currentPrice"
                type="number"
                min="0.000001"
                step="any"
                placeholder="51000"
                value={newInvestment.currentPrice || ''}
                onChange={(e) => setNewInvestment({...newInvestment, currentPrice: parseFloat(e.target.value) || 0})}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="quantity">Quantity</Label>
              <Input
                id="quantity"
                type="number"
                min="0.000001"
                step="any"
                placeholder="0.5"
                value={newInvestment.quantity || ''}
                onChange={(e) => setNewInvestment({...newInvestment, quantity: parseFloat(e.target.value) || 0})}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleAddInvestment} className="crypto-gradient-bg">
              Add Investment
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Investment Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Investment</DialogTitle>
            <DialogDescription>
              Update the details of your cryptocurrency investment.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-name">Coin Name</Label>
                <Input
                  id="edit-name"
                  value={newInvestment.name}
                  onChange={(e) => setNewInvestment({...newInvestment, name: e.target.value})}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-symbol">Symbol</Label>
                <Input
                  id="edit-symbol"
                  value={newInvestment.symbol}
                  onChange={(e) => setNewInvestment({...newInvestment, symbol: e.target.value.toUpperCase()})}
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-buyPrice">Buy Price (USD)</Label>
              <Input
                id="edit-buyPrice"
                type="number"
                min="0.000001"
                step="any"
                value={newInvestment.buyPrice || ''}
                onChange={(e) => setNewInvestment({...newInvestment, buyPrice: parseFloat(e.target.value) || 0})}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-currentPrice">Current Price (USD)</Label>
              <Input
                id="edit-currentPrice"
                type="number"
                min="0.000001"
                step="any"
                value={newInvestment.currentPrice || ''}
                onChange={(e) => setNewInvestment({...newInvestment, currentPrice: parseFloat(e.target.value) || 0})}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-quantity">Quantity</Label>
              <Input
                id="edit-quantity"
                type="number"
                min="0.000001"
                step="any"
                value={newInvestment.quantity || ''}
                onChange={(e) => setNewInvestment({...newInvestment, quantity: parseFloat(e.target.value) || 0})}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => {
              setIsEditDialogOpen(false);
              setEditInvestmentId(null);
              resetNewInvestment();
            }}>
              Cancel
            </Button>
            <Button onClick={handleEditInvestment} className="crypto-gradient-bg">
              Update Investment
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default InvestmentTracker;
