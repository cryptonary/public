
import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Calculator, TrendingUp, TrendingDown, ArrowRight } from "lucide-react";
import { Helmet } from "react-helmet-async";

const ProfitCalculator = () => {
  const [investmentAmount, setInvestmentAmount] = useState<string>("1000");
  const [buyPrice, setBuyPrice] = useState<string>("50000");
  const [sellPrice, setSellPrice] = useState<string>("60000");
  const [profit, setProfit] = useState<number>(0);
  const [profitPercentage, setProfitPercentage] = useState<number>(0);
  const [coinAmount, setCoinAmount] = useState<number>(0);

  useEffect(() => {
    calculateProfit();
  }, [investmentAmount, buyPrice, sellPrice]);

  const calculateProfit = () => {
    const investment = parseFloat(investmentAmount) || 0;
    const buy = parseFloat(buyPrice) || 0;
    const sell = parseFloat(sellPrice) || 0;
    
    if (buy <= 0 || investment <= 0) {
      setProfit(0);
      setProfitPercentage(0);
      setCoinAmount(0);
      return;
    }
    
    const coins = investment / buy;
    const finalValue = coins * sell;
    const calculatedProfit = finalValue - investment;
    const calculatedPercentage = ((finalValue / investment) - 1) * 100;
    
    setCoinAmount(coins);
    setProfit(calculatedProfit);
    setProfitPercentage(calculatedPercentage);
  };

  const formatCurrency = (value: number): string => {
    return new Intl.NumberFormat('en-US', { 
      style: 'currency', 
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(value);
  };

  const faqs = [
    {
      question: "How does the profit calculator work?",
      answer: "The profit calculator takes three primary inputs: your initial investment amount, the buying price per coin, and the selling price per coin. It then calculates how many coins you could purchase with your investment, the final value of those coins at the selling price, and the resulting profit or loss in both monetary value and percentage terms."
    },
    {
      question: "Can I calculate losses as well as profits?",
      answer: "Yes, if the selling price you enter is lower than the buying price, the calculator will show your potential loss as a negative profit value and percentage."
    },
    {
      question: "Does this calculator account for trading fees?",
      answer: "No, this basic version of the calculator does not include trading fees, spread costs, or taxes. These would reduce your actual profits or increase your losses. You should factor these costs separately when making investment decisions."
    },
    {
      question: "How accurate are these calculations?",
      answer: "The calculations are mathematically accurate based on the inputs provided. However, real-world cryptocurrency trading involves additional factors like slippage, liquidity issues, and market volatility that may affect actual results."
    },
    {
      question: "Can I save or share my calculation results?",
      answer: "Currently, there's no built-in functionality to save or share results. However, you can take screenshots or note down the calculated values for your reference."
    }
  ];

  return (
    <div className="container py-10 md:py-20 max-w-4xl">
      <Helmet>
        <title>Crypto Profit Calculator - Calculate Potential Returns</title>
        <meta name="description" content="Calculate potential profits or losses from your cryptocurrency investments with our easy-to-use profit calculator." />
        <meta name="keywords" content="crypto profit calculator, cryptocurrency calculator, investment returns, crypto ROI" />
        <script type="application/ld+json">
          {JSON.stringify({
            "@context": "https://schema.org",
            "@type": "SoftwareApplication",
            "name": "Crypto Profit Calculator",
            "applicationCategory": "FinanceApplication",
            "operatingSystem": "Web",
            "offers": {
              "@type": "Offer",
              "price": "0",
              "priceCurrency": "USD"
            },
            "description": "Calculate potential profits or losses from cryptocurrency investments."
          })}
        </script>
        <script type="application/ld+json">
          {JSON.stringify({
            "@context": "https://schema.org",
            "@type": "FAQPage",
            "mainEntity": faqs.map(faq => ({
              "@type": "Question",
              "name": faq.question,
              "acceptedAnswer": {
                "@type": "Answer",
                "text": faq.answer
              }
            }))
          })}
        </script>
      </Helmet>

      <div className="text-center mb-10">
        <h1 className="text-3xl md:text-4xl font-bold mb-4">Crypto Profit Calculator</h1>
        <p className="text-muted-foreground max-w-3xl mx-auto">
          Calculate your potential profits or losses from cryptocurrency investments. Simply enter your investment 
          amount, the price at which you bought (or plan to buy) your coins, and the price at which you plan to sell. 
          Our calculator will show you the potential profit or loss in both dollar value and percentage.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Input Section */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <Calculator className="text-crypto-purple" />
              <CardTitle>Investment Details</CardTitle>
            </div>
            <CardDescription>Enter your investment parameters</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="investmentAmount">Investment Amount (USD)</Label>
              <Input
                id="investmentAmount"
                type="number"
                min="0"
                step="any"
                value={investmentAmount}
                onChange={(e) => setInvestmentAmount(e.target.value)}
                className="input-field"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="buyPrice">Buying Price per Coin (USD)</Label>
              <Input
                id="buyPrice"
                type="number"
                min="0.000001" 
                step="any"
                value={buyPrice}
                onChange={(e) => setBuyPrice(e.target.value)}
                className="input-field"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="sellPrice">Selling Price per Coin (USD)</Label>
              <Input
                id="sellPrice"
                type="number"
                min="0.000001"
                step="any"
                value={sellPrice}
                onChange={(e) => setSellPrice(e.target.value)}
                className="input-field"
              />
            </div>
          </CardContent>
        </Card>

        {/* Results Section */}
        <Card className="bg-card/50">
          <CardHeader>
            <div className="flex items-center gap-2">
              {profit >= 0 ? 
                <TrendingUp className="text-green-500" /> : 
                <TrendingDown className="text-red-500" />
              }
              <CardTitle>Investment Results</CardTitle>
            </div>
            <CardDescription>Your calculated profit or loss</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-center gap-4 my-6">
              <div className="text-center p-4 bg-background rounded-lg flex-1">
                <p className="text-sm text-muted-foreground mb-1">Investment</p>
                <p className="text-xl font-semibold">{formatCurrency(parseFloat(investmentAmount) || 0)}</p>
              </div>
              <ArrowRight className="text-muted-foreground" />
              <div className="text-center p-4 bg-background rounded-lg flex-1">
                <p className="text-sm text-muted-foreground mb-1">Final Value</p>
                <p className="text-xl font-semibold">
                  {formatCurrency((parseFloat(investmentAmount) || 0) + profit)}
                </p>
              </div>
            </div>
            
            <div className="space-y-4">
              <div className="p-4 rounded-lg border border-border/50">
                <p className="text-sm text-muted-foreground">Coin Amount</p>
                <p className="text-2xl font-bold">{coinAmount.toFixed(8)}</p>
              </div>
              
              <div className="p-4 rounded-lg border border-border/50">
                <p className="text-sm text-muted-foreground">Profit/Loss</p>
                <p className={`text-2xl font-bold ${profit >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                  {formatCurrency(profit)}
                </p>
              </div>
              
              <div className="p-4 rounded-lg border border-border/50">
                <p className="text-sm text-muted-foreground">Profit/Loss Percentage</p>
                <p className={`text-2xl font-bold ${profitPercentage >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                  {profitPercentage.toFixed(2)}%
                </p>
              </div>
            </div>
          </CardContent>
          <CardFooter className="text-xs text-muted-foreground">
            Results are calculated based on the parameters you entered.
          </CardFooter>
        </Card>
      </div>

      {/* Understanding Crypto Profits Section */}
      <div className="mt-16">
        <h2 className="text-2xl font-bold mb-6 text-center">Understanding Cryptocurrency Profits</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <h3 className="text-xl font-semibold mb-3">Key Factors in Crypto Investing</h3>
            <ul className="list-disc pl-5 space-y-2 text-muted-foreground">
              <li>
                <span className="font-semibold">Entry and exit points:</span> The prices at which you buy and sell cryptocurrencies are the primary determinants of your profits or losses.
              </li>
              <li>
                <span className="font-semibold">Investment amount:</span> Your initial investment determines how many coins you can purchase and influences the magnitude of potential returns.
              </li>
              <li>
                <span className="font-semibold">Market volatility:</span> Cryptocurrency markets are known for significant price swings, which can lead to substantial profits or losses.
              </li>
              <li>
                <span className="font-semibold">Fees and taxes:</span> Trading fees, spread costs, and applicable taxes can significantly impact your net profits.
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-xl font-semibold mb-3">Making Smart Investment Decisions</h3>
            <ul className="list-disc pl-5 space-y-2 text-muted-foreground">
              <li>
                <span className="font-semibold">Set clear targets:</span> Decide on profit-taking levels before investing to avoid emotional decision-making.
              </li>
              <li>
                <span className="font-semibold">Diversify investments:</span> Spread your investments across multiple cryptocurrencies to reduce risk.
              </li>
              <li>
                <span className="font-semibold">Consider dollar-cost averaging:</span> Investing fixed amounts regularly can help manage volatility risk.
              </li>
              <li>
                <span className="font-semibold">Stay informed:</span> Keep up with market news and developments that might affect cryptocurrency prices.
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* FAQs */}
      <div className="mt-16">
        <h2 className="text-2xl font-bold mb-6 text-center">Frequently Asked Questions</h2>
        
        <div className="space-y-6">
          {faqs.map((faq, index) => (
            <div key={index} className="border border-border/50 rounded-lg p-6">
              <h3 className="text-xl font-semibold mb-2">{faq.question}</h3>
              <p className="text-muted-foreground">{faq.answer}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ProfitCalculator;
