
import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BarChart2, LineChart as LineChartIcon, ArrowRight, RefreshCw } from "lucide-react";
import { LineChart, CartesianGrid, XAxis, YAxis, Tooltip, Legend, Line, ResponsiveContainer } from "recharts";
import { Helmet } from "react-helmet-async";

interface PricePoint {
  day: number;
  price: number;
  movingAverage7?: number;
  movingAverage30?: number;
}

const PriceSimulator = () => {
  const [initialPrice, setInitialPrice] = useState<string>("50000");
  const [volatility, setVolatility] = useState<number>(5); // Percentage
  const [timeframeOption, setTimeframeOption] = useState<string>("30");
  const [simulatedPrices, setSimulatedPrices] = useState<PricePoint[]>([]);
  const [scenarioType, setScenarioType] = useState<string>("random");

  useEffect(() => {
    simulatePrices();
  }, [initialPrice, volatility, timeframeOption, scenarioType]);

  const simulatePrices = () => {
    const price = parseFloat(initialPrice) || 0;
    const days = parseInt(timeframeOption) || 30;
    
    if (price <= 0) {
      setSimulatedPrices([]);
      return;
    }
    
    const prices: PricePoint[] = [];
    let currentPrice = price;
    
    // Add initial price point
    prices.push({ day: 0, price: currentPrice });
    
    for (let day = 1; day <= days; day++) {
      // Generate next price based on scenario
      switch (scenarioType) {
        case 'bullish':
          // Bullish scenario - upward trend with volatility
          currentPrice = calculateNextPrice(currentPrice, volatility, 0.65); // 65% chance of going up
          break;
          
        case 'bearish':
          // Bearish scenario - downward trend with volatility
          currentPrice = calculateNextPrice(currentPrice, volatility, 0.35); // 35% chance of going up
          break;
          
        case 'sideways':
          // Sideways scenario - oscillation around initial price
          const deviation = (Math.random() - 0.5) * (volatility / 100) * price;
          currentPrice = price + deviation;
          break;
          
        case 'random':
        default:
          // Random scenario - pure volatility
          currentPrice = calculateNextPrice(currentPrice, volatility, 0.5); // 50% chance of going up
      }
      
      prices.push({ day, price: currentPrice });
    }
    
    // Calculate moving averages
    const pricesWithMovingAverages = calculateMovingAverages(prices);
    setSimulatedPrices(pricesWithMovingAverages);
  };
  
  const calculateNextPrice = (current: number, vol: number, bullishBias: number): number => {
    // Simulate random price movement with a bias factor (bullish > 0.5, bearish < 0.5)
    const percentChange = (Math.random() < bullishBias ? 1 : -1) * (Math.random() * vol / 100);
    return current * (1 + percentChange);
  };
  
  const calculateMovingAverages = (prices: PricePoint[]): PricePoint[] => {
    return prices.map((point, index) => {
      // Calculate 7-day moving average if possible
      let ma7 = undefined;
      if (index >= 6) {
        const last7Days = prices.slice(index - 6, index + 1);
        ma7 = last7Days.reduce((sum, p) => sum + p.price, 0) / 7;
      }
      
      // Calculate 30-day moving average if possible
      let ma30 = undefined;
      if (index >= 29) {
        const last30Days = prices.slice(index - 29, index + 1);
        ma30 = last30Days.reduce((sum, p) => sum + p.price, 0) / 30;
      }
      
      return { ...point, movingAverage7: ma7, movingAverage30: ma30 };
    });
  };

  const formatCurrency = (value: number): string => {
    return new Intl.NumberFormat('en-US', { 
      style: 'currency', 
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(value);
  };

  const getStatistics = () => {
    if (simulatedPrices.length < 2) return { min: 0, max: 0, avg: 0, change: 0, changePercent: 0 };
    
    const prices = simulatedPrices.map(p => p.price);
    const min = Math.min(...prices);
    const max = Math.max(...prices);
    const avg = prices.reduce((sum, p) => sum + p, 0) / prices.length;
    
    const firstPrice = simulatedPrices[0].price;
    const lastPrice = simulatedPrices[simulatedPrices.length - 1].price;
    const change = lastPrice - firstPrice;
    const changePercent = (change / firstPrice) * 100;
    
    return { min, max, avg, change, changePercent };
  };

  const stats = getStatistics();

  const faqs = [
    {
      question: "How does the price simulator work?",
      answer: "Our price simulator uses statistical models to generate simulated price movements based on the parameters you set. It starts with your specified initial price and then calculates subsequent prices using random variations controlled by the volatility percentage and market scenario you select."
    },
    {
      question: "How realistic are these price simulations?",
      answer: "While our simulator incorporates elements of real market behavior like volatility and trend patterns, it's important to understand these are simplified simulations, not predictions. Real cryptocurrency markets are influenced by countless factors including news events, regulatory changes, market sentiment, and technological developments that cannot be fully modeled."
    },
    {
      question: "What do the different market scenarios represent?",
      answer: "The 'Random' scenario applies pure volatility with no directional bias. 'Bullish' introduces an upward bias to price movements (more likely to rise than fall). 'Bearish' creates a downward bias (more likely to fall than rise). 'Sideways' keeps prices oscillating around the initial price without a strong directional trend."
    },
    {
      question: "What are moving averages and how should I interpret them?",
      answer: "Moving averages are technical indicators that smooth out price data by creating a constantly updated average price over a specific period. The 7-day moving average (MA) represents short-term trends, while the 30-day MA indicates medium-term trends. When the price crosses above a moving average, it might signal an uptrend; crossing below could suggest a downtrend."
    },
    {
      question: "Can I use these simulations for investment decisions?",
      answer: "While our simulator can help visualize potential price scenarios and volatility effects, it should not be used as the sole basis for investment decisions. It's best used as an educational tool to understand concepts like volatility and price trends, rather than as a predictive tool for actual market movements."
    }
  ];

  return (
    <div className="container py-10 md:py-20">
      <Helmet>
        <title>Crypto Price Simulator - Visualize Market Scenarios</title>
        <meta name="description" content="Visualize potential price movements of cryptocurrencies with our interactive simulator. Test different market scenarios and volatility levels." />
        <meta name="keywords" content="crypto price simulator, cryptocurrency prediction, market scenarios, price volatility, technical indicators" />
        <script type="application/ld+json">
          {JSON.stringify({
            "@context": "https://schema.org",
            "@type": "SoftwareApplication",
            "name": "Crypto Price Simulator",
            "applicationCategory": "FinanceApplication",
            "operatingSystem": "Web",
            "offers": {
              "@type": "Offer",
              "price": "0",
              "priceCurrency": "USD"
            },
            "description": "Visualize and simulate potential price movements of cryptocurrencies with different market scenarios."
          })}
        </script>
        <script type="application/ld+json">
          {JSON.stringify({
            "@context": "https://schema.org",
            "@type": "FAQPage",
            "mainEntity": faqs.map(faq => ({
              "@type": "Question",
              "name": faq.question,
              "acceptedAnswer": {
                "@type": "Answer",
                "text": faq.answer
              }
            }))
          })}
        </script>
      </Helmet>

      <div className="text-center mb-10">
        <h1 className="text-3xl md:text-4xl font-bold mb-4">Crypto Price Simulator</h1>
        <p className="text-muted-foreground max-w-3xl mx-auto">
          Explore potential price movements of cryptocurrencies under different market scenarios. 
          This simulator helps visualize how factors like volatility and market trends might affect 
          cryptocurrency prices over time, providing insights for your investment strategy planning.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Control Panel */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <div className="flex items-center gap-2">
              <BarChart2 className="text-crypto-purple" />
              <CardTitle>Simulation Settings</CardTitle>
            </div>
            <CardDescription>Configure your price prediction model</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="initialPrice">Initial Price (USD)</Label>
              <Input
                id="initialPrice"
                type="number"
                min="0.01"
                step="any"
                value={initialPrice}
                onChange={(e) => setInitialPrice(e.target.value)}
                className="input-field"
              />
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between">
                <Label htmlFor="volatility">Volatility: {volatility}%</Label>
              </div>
              <Slider
                id="volatility"
                min={1}
                max={20}
                step={1}
                value={[volatility]}
                onValueChange={(value) => setVolatility(value[0])}
              />
              <p className="text-xs text-muted-foreground">
                Higher volatility means more price fluctuations in the simulation.
              </p>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="timeframe">Timeframe (Days)</Label>
              <Select value={timeframeOption} onValueChange={setTimeframeOption}>
                <SelectTrigger id="timeframe">
                  <SelectValue placeholder="Select timeframe" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="7">7 Days</SelectItem>
                  <SelectItem value="30">30 Days</SelectItem>
                  <SelectItem value="90">90 Days</SelectItem>
                  <SelectItem value="180">180 Days</SelectItem>
                  <SelectItem value="365">365 Days</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="scenario">Market Scenario</Label>
              <Select value={scenarioType} onValueChange={setScenarioType}>
                <SelectTrigger id="scenario">
                  <SelectValue placeholder="Select scenario" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="random">Random</SelectItem>
                  <SelectItem value="bullish">Bullish Trend</SelectItem>
                  <SelectItem value="bearish">Bearish Trend</SelectItem>
                  <SelectItem value="sideways">Sideways Market</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <Button 
              onClick={simulatePrices} 
              className="w-full"
              variant="secondary"
            >
              <RefreshCw className="mr-2 h-4 w-4" /> Regenerate Simulation
            </Button>
          </CardContent>
        </Card>

        {/* Visualization */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <div className="flex items-center gap-2">
              <LineChartIcon className="text-crypto-purple" />
              <CardTitle>Price Prediction</CardTitle>
            </div>
            <CardDescription>Simulated price movement over time</CardDescription>
          </CardHeader>
          <CardContent>
            {/* Price Statistics */}
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6">
              <div className="p-3 bg-accent/30 rounded-lg text-center">
                <p className="text-xs text-muted-foreground mb-1">Start Price</p>
                <p className="text-sm font-semibold">{formatCurrency(parseFloat(initialPrice) || 0)}</p>
              </div>
              <div className="p-3 bg-accent/30 rounded-lg text-center">
                <p className="text-xs text-muted-foreground mb-1">Final Price</p>
                <p className="text-sm font-semibold">
                  {simulatedPrices.length > 0 ? formatCurrency(simulatedPrices[simulatedPrices.length - 1].price) : '-'}
                </p>
              </div>
              <div className="p-3 bg-accent/30 rounded-lg text-center">
                <p className="text-xs text-muted-foreground mb-1">Min Price</p>
                <p className="text-sm font-semibold">{formatCurrency(stats.min)}</p>
              </div>
              <div className="p-3 bg-accent/30 rounded-lg text-center">
                <p className="text-xs text-muted-foreground mb-1">Max Price</p>
                <p className="text-sm font-semibold">{formatCurrency(stats.max)}</p>
              </div>
              <div className="p-3 bg-accent/30 rounded-lg text-center col-span-2 md:col-span-1">
                <p className="text-xs text-muted-foreground mb-1">Price Change</p>
                <p className={`text-sm font-semibold ${stats.change >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                  {formatCurrency(stats.change)} ({stats.changePercent.toFixed(2)}%)
                </p>
              </div>
            </div>

            {/* Chart Tabs */}
            <Tabs defaultValue="line">
              <TabsList className="grid grid-cols-2 mb-4">
                <TabsTrigger value="line">Line Chart</TabsTrigger>
                <TabsTrigger value="technical">Technical Indicators</TabsTrigger>
              </TabsList>
              
              <TabsContent value="line">
                <div className="h-96">
                  {simulatedPrices.length > 0 ? (
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={simulatedPrices}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis 
                          dataKey="day" 
                          label={{ value: 'Day', position: 'insideBottom', offset: -5 }} 
                        />
                        <YAxis 
                          label={{ value: 'Price (USD)', angle: -90, position: 'insideLeft' }}
                          tickFormatter={(value) => value.toLocaleString()} 
                        />
                        <Tooltip formatter={(value: number) => formatCurrency(value)} />
                        <Legend />
                        <Line 
                          type="monotone" 
                          dataKey="price" 
                          name="Price"
                          stroke="#8B5CF6" 
                          strokeWidth={2} 
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  ) : (
                    <div className="h-full flex items-center justify-center">
                      <p className="text-muted-foreground">Enter valid parameters to see the simulation.</p>
                    </div>
                  )}
                </div>
              </TabsContent>
              
              <TabsContent value="technical">
                <div className="h-96">
                  {simulatedPrices.length > 0 ? (
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={simulatedPrices}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis 
                          dataKey="day" 
                          label={{ value: 'Day', position: 'insideBottom', offset: -5 }} 
                        />
                        <YAxis 
                          label={{ value: 'Price (USD)', angle: -90, position: 'insideLeft' }}
                          tickFormatter={(value) => value.toLocaleString()} 
                        />
                        <Tooltip formatter={(value: number) => formatCurrency(value)} />
                        <Legend />
                        <Line 
                          type="monotone" 
                          dataKey="price" 
                          name="Price"
                          stroke="#8B5CF6" 
                          strokeWidth={1.5} 
                        />
                        <Line 
                          type="monotone" 
                          dataKey="movingAverage7" 
                          name="7-Day MA"
                          stroke="#F97316" 
                          strokeWidth={1} 
                          dot={false} 
                        />
                        <Line 
                          type="monotone" 
                          dataKey="movingAverage30" 
                          name="30-Day MA"
                          stroke="#0EA5E9" 
                          strokeWidth={1} 
                          dot={false} 
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  ) : (
                    <div className="h-full flex items-center justify-center">
                      <p className="text-muted-foreground">Enter valid parameters to see the simulation with technical indicators.</p>
                    </div>
                  )}
                </div>
                <div className="mt-4 p-4 bg-accent/20 rounded-lg">
                  <p className="text-sm">
                    <span className="font-medium">Technical Indicators:</span> The chart includes 7-day and 30-day moving averages that help identify trends in the simulated price movement.
                  </p>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>

      {/* Understanding Price Simulation */}
      <div className="mt-16">
        <h2 className="text-2xl font-bold mb-6 text-center">Understanding Price Simulation</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <h3 className="text-xl font-semibold mb-3">What Affects Cryptocurrency Prices</h3>
            <p className="text-muted-foreground mb-4">
              In real markets, cryptocurrency prices are influenced by multiple factors:
            </p>
            <ul className="list-disc pl-5 space-y-2 text-muted-foreground">
              <li>
                <span className="font-semibold">Market sentiment:</span> Overall optimism or pessimism in the market
              </li>
              <li>
                <span className="font-semibold">Adoption and utility:</span> The practical applications and user base growth
              </li>
              <li>
                <span className="font-semibold">Regulatory news:</span> Government actions regarding cryptocurrency regulation
              </li>
              <li>
                <span className="font-semibold">Technological developments:</span> Updates, upgrades, or security concerns
              </li>
              <li>
                <span className="font-semibold">Macroeconomic factors:</span> Inflation, interest rates, and global economic conditions
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-xl font-semibold mb-3">Using Simulations Effectively</h3>
            <p className="text-muted-foreground mb-4">
              While simulations can't predict the future, they can help you:
            </p>
            <ul className="list-disc pl-5 space-y-2 text-muted-foreground">
              <li>
                <span className="font-semibold">Stress-test strategies:</span> See how your investment might perform under different market conditions
              </li>
              <li>
                <span className="font-semibold">Understand volatility impact:</span> Visualize how price volatility affects returns over time
              </li>
              <li>
                <span className="font-semibold">Practice technical analysis:</span> Learn how indicators like moving averages relate to price movements
              </li>
              <li>
                <span className="font-semibold">Set realistic expectations:</span> Develop a more nuanced understanding of potential price ranges
              </li>
              <li>
                <span className="font-semibold">Plan risk management:</span> Determine appropriate stop-loss or take-profit levels based on simulated volatility
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* FAQs */}
      <div className="mt-16">
        <h2 className="text-2xl font-bold mb-6 text-center">Frequently Asked Questions</h2>
        
        <div className="space-y-6">
          {faqs.map((faq, index) => (
            <div key={index} className="border border-border/50 rounded-lg p-6">
              <h3 className="text-xl font-semibold mb-2">{faq.question}</h3>
              <p className="text-muted-foreground">{faq.answer}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default PriceSimulator;
