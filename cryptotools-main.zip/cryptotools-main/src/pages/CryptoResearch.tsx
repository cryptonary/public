
import { Helmet } from "react-helmet-async";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";
import { ExternalLink } from "lucide-react";
import { 
  Accordion, 
  AccordionContent, 
  AccordionItem, 
  AccordionTrigger 
} from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";

const CryptoResearch = () => {
  return (
    <div className="container py-8 space-y-8">
      {/* SEO Helmet */}
      <Helmet>
        <title>Crypto Research Tools - Cryptocurrency Analysis & Resources</title>
        <meta name="description" content="Access comprehensive cryptocurrency research tools, analysis, reports, AI news, live prices, and token information to make informed investment decisions." />
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "SoftwareApplication",
              "name": "CryptoTools Research",
              "applicationCategory": "FinanceApplication",
              "offers": {
                "@type": "Offer",
                "price": "0"
              },
              "aggregateRating": {
                "@type": "AggregateRating",
                "ratingValue": "4.8",
                "ratingCount": "789"
              }
            }
          `}
        </script>
      </Helmet>

      {/* Hero Section */}
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold tracking-tight">Crypto Research Tools</h1>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          Comprehensive tools and resources to help you make informed decisions in the cryptocurrency market
        </p>
      </div>
      
      <Separator />

      {/* Main Content */}
      <div className="grid md:grid-cols-2 gap-8">
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>Advanced Crypto Research</CardTitle>
            <CardDescription>
              Access high-quality analysis tools and research materials to help you navigate the cryptocurrency market with confidence.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <p>
              Our research tools provide comprehensive insights into the cryptocurrency market, helping you make informed investment decisions based on reliable data and expert analysis.
            </p>
            <p>
              <a 
                href="https://cryptonary.com/cryptoschool/free-crypto-research-tools/" 
                className="text-primary underline flex items-center hover:text-primary/80 gap-1"
                target="_blank"
                rel="noopener noreferrer"
              >
                Crypto Research, Reports, AI News, Live Prices, Token
                <ExternalLink size={16} />
              </a>
            </p>
            <p>
              Powered by industry-leading analytics and up-to-date market data, our tools help you stay ahead in the fast-moving crypto landscape.
            </p>
          </CardContent>
        </Card>

        {/* Features Section */}
        <Card>
          <CardHeader>
            <CardTitle>Market Analysis Tools</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <h3 className="font-medium">Price Analysis</h3>
              <p className="text-sm text-muted-foreground">
                Track real-time price movements and historical data to identify trends and patterns.
              </p>
            </div>
            <div className="space-y-2">
              <h3 className="font-medium">Technical Indicators</h3>
              <p className="text-sm text-muted-foreground">
                Access popular technical indicators like RSI, MACD, and moving averages to guide your trading decisions.
              </p>
            </div>
            <div className="space-y-2">
              <h3 className="font-medium">Market Sentiment</h3>
              <p className="text-sm text-muted-foreground">
                Gauge market sentiment through social media analysis and news sentiment tracking.
              </p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Research Resources</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <h3 className="font-medium">Token Fundamentals</h3>
              <p className="text-sm text-muted-foreground">
                Evaluate cryptocurrencies based on tokenomics, team information, and development activity.
              </p>
            </div>
            <div className="space-y-2">
              <h3 className="font-medium">Project Insights</h3>
              <p className="text-sm text-muted-foreground">
                Access detailed project analyses, roadmap evaluations, and potential risk assessments.
              </p>
            </div>
            <div className="space-y-2">
              <h3 className="font-medium">Expert Reports</h3>
              <p className="text-sm text-muted-foreground">
                Read comprehensive reports from crypto analysts and industry experts.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* CTA Section */}
        <Card className="md:col-span-2 bg-primary/5">
          <CardHeader>
            <CardTitle>Access Premium Research</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p>
              For more advanced research tools and in-depth analysis, visit Cryptonary's comprehensive research platform.
            </p>
            <Button asChild>
              <a 
                href="https://cryptonary.com/cryptoschool/free-crypto-research-tools/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center gap-2"
              >
                Explore Cryptonary Research
                <ExternalLink size={16} />
              </a>
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* FAQ Section */}
      <div className="space-y-4">
        <h2 className="text-2xl font-bold">Frequently Asked Questions</h2>
        
        <Accordion type="single" collapsible className="w-full">
          <AccordionItem value="item-1">
            <AccordionTrigger>What types of crypto research tools are available?</AccordionTrigger>
            <AccordionContent>
              Our platform offers various research tools including price analysis, technical indicators, fundamental analysis, social sentiment tracking, and comprehensive project reports. These tools help you make informed decisions based on reliable data and expert insights.
            </AccordionContent>
          </AccordionItem>
          
          <AccordionItem value="item-2">
            <AccordionTrigger>How often is the research data updated?</AccordionTrigger>
            <AccordionContent>
              Most of our market data is updated in real-time or near real-time. Research reports and in-depth analyses are published regularly, with major reports typically released on a weekly or monthly basis depending on market conditions and significant developments.
            </AccordionContent>
          </AccordionItem>
          
          <AccordionItem value="item-3">
            <AccordionTrigger>Do you provide recommendations on specific cryptocurrencies?</AccordionTrigger>
            <AccordionContent>
              While we provide comprehensive analysis and research tools, we do not offer specific investment recommendations. Our goal is to equip you with the information and tools you need to make your own informed decisions based on your investment goals and risk tolerance.
            </AccordionContent>
          </AccordionItem>
          
          <AccordionItem value="item-4">
            <AccordionTrigger>How can I use these research tools effectively?</AccordionTrigger>
            <AccordionContent>
              To use our research tools effectively, start by defining your investment goals and strategy. Use technical analysis tools for short-term trading decisions, fundamental analysis for long-term investment potential, and sentiment analysis to gauge market mood. Combine multiple data points rather than relying on a single indicator for more robust decision-making.
            </AccordionContent>
          </AccordionItem>
          
          <AccordionItem value="item-5">
            <AccordionTrigger>Where does your research data come from?</AccordionTrigger>
            <AccordionContent>
              Our research data comes from various reliable sources, including cryptocurrency exchanges, blockchain explorers, social media platforms, news outlets, and reputable data providers in the industry. We also collaborate with Cryptonary and other crypto research firms to provide comprehensive and accurate information.
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      </div>

      {/* Schema Data for Content */}
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: `
        {
          "@context": "https://schema.org",
          "@type": "Article",
          "headline": "Crypto Research Tools: Comprehensive Analysis Resources",
          "description": "Access comprehensive cryptocurrency research tools, analysis, reports, AI news, live prices, and token information to make informed investment decisions.",
          "author": {
            "@type": "Organization",
            "name": "CryptoTools"
          },
          "publisher": {
            "@type": "Organization",
            "name": "CryptoTools",
            "logo": {
              "@type": "ImageObject",
              "url": "https://lovable.dev/opengraph-image-p98pqg.png"
            }
          },
          "datePublished": "2023-05-06",
          "dateModified": "2023-05-06"
        }
      `}} />

      {/* FAQ Schema */}
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: `
        {
          "@context": "https://schema.org",
          "@type": "FAQPage",
          "mainEntity": [
            {
              "@type": "Question",
              "name": "What types of crypto research tools are available?",
              "acceptedAnswer": {
                "@type": "Answer",
                "text": "Our platform offers various research tools including price analysis, technical indicators, fundamental analysis, social sentiment tracking, and comprehensive project reports. These tools help you make informed decisions based on reliable data and expert insights."
              }
            },
            {
              "@type": "Question",
              "name": "How often is the research data updated?",
              "acceptedAnswer": {
                "@type": "Answer",
                "text": "Most of our market data is updated in real-time or near real-time. Research reports and in-depth analyses are published regularly, with major reports typically released on a weekly or monthly basis depending on market conditions and significant developments."
              }
            },
            {
              "@type": "Question",
              "name": "Do you provide recommendations on specific cryptocurrencies?",
              "acceptedAnswer": {
                "@type": "Answer",
                "text": "While we provide comprehensive analysis and research tools, we do not offer specific investment recommendations. Our goal is to equip you with the information and tools you need to make your own informed decisions based on your investment goals and risk tolerance."
              }
            },
            {
              "@type": "Question",
              "name": "How can I use these research tools effectively?",
              "acceptedAnswer": {
                "@type": "Answer",
                "text": "To use our research tools effectively, start by defining your investment goals and strategy. Use technical analysis tools for short-term trading decisions, fundamental analysis for long-term investment potential, and sentiment analysis to gauge market mood. Combine multiple data points rather than relying on a single indicator for more robust decision-making."
              }
            },
            {
              "@type": "Question",
              "name": "Where does your research data come from?",
              "acceptedAnswer": {
                "@type": "Answer",
                "text": "Our research data comes from various reliable sources, including cryptocurrency exchanges, blockchain explorers, social media platforms, news outlets, and reputable data providers in the industry. We also collaborate with Cryptonary and other crypto research firms to provide comprehensive and accurate information."
              }
            }
          ]
        }
      `}} />
    </div>
  );
};

export default CryptoResearch;
