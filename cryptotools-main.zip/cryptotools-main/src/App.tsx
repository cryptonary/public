
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { ThemeProvider } from "@/components/theme/theme-provider";
import { HelmetProvider } from "react-helmet-async";

import Layout from "./components/layout/Layout";
import HomePage from "./pages/HomePage";
import ProfitCalculator from "./pages/ProfitCalculator";
import DcaCalculator from "./pages/DcaCalculator";
import CryptoConverter from "./pages/CryptoConverter";
import InvestmentTracker from "./pages/InvestmentTracker";
import PriceSimulator from "./pages/PriceSimulator";
import CryptoResearch from "./pages/CryptoResearch";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <HelmetProvider>
    <QueryClientProvider client={queryClient}>
      <ThemeProvider defaultTheme="dark" storageKey="crypto-theme">
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <Routes>
              <Route path="/" element={<Layout />}>
                <Route index element={<HomePage />} />
                <Route path="profit-calculator" element={<ProfitCalculator />} />
                <Route path="dca-calculator" element={<DcaCalculator />} />
                <Route path="crypto-converter" element={<CryptoConverter />} />
                <Route path="investment-tracker" element={<InvestmentTracker />} />
                <Route path="price-simulator" element={<PriceSimulator />} />
                <Route path="crypto-research" element={<CryptoResearch />} />
                <Route path="*" element={<NotFound />} />
              </Route>
            </Routes>
          </BrowserRouter>
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  </HelmetProvider>
);

export default App;
